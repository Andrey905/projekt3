
from flask import *
import datetime
import sqlite3

app = Flask(__name__)
ButtonPressed = 0

@app.route('/', methods=['POST', 'GET'])
def form_sample():
    global ButtonPressed
    #if request.method == 'GET':
     #   return render_template('base.html')
    if request.method == 'POST':
        ButtonPressed += 1
        #print(request.form['calendar'])
        return render_template('base.html', ButtonPressed=ButtonPressed)
    return render_template("base.html", ButtonPressed=ButtonPressed)

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')