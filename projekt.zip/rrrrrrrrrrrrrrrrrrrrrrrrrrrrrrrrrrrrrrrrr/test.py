
from flask import *
import datetime
import sqlite3
global_data = datetime.datetime.today()
months_day = ('Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября',\
'Октября', 'Ноября', 'Декабря')

def homework(date, nam_lesson):
    date = date.strftime('%Y-%m-%d')
    con = sqlite3.connect("blogs.db")
    cur = con.cursor()
    result = cur.execute("""SELECT dd.date, sh.lesson_num, lt.lessontime, ls.lesson_name, ls.lesson_name_eng, hw.result_type, hw.text_homework
                            FROM D_Schedule sh, BE_WeekDay wd, D_Lesson ls, BE_lesson_Time lt, WeekDay_DateDay dd, HomeWork hw, ScheduleFact sf
                            WHERE sh.weekday_id = wd.id
                            AND sh.lesson_id = ls.id
                            AND sh.lesson_num = lt.lesson_num
                            AND sh.id = sf.schedule_id
                            AND hw.schedulefact_id = sf.id
                            AND dd.id = hw.date_id
                            AND dd.date = date('2021-04-23')
                            AND sh.lesson_num = 4
                            ORDER BY sh.lesson_num""").fetchall()
    con.close()
    return result


def tomorrow(now):
    list_less = []
    week_day = now.weekday() + 1
    con = sqlite3.connect("blogs.db")

    cur = con.cursor()

    result = cur.execute("""SELECT sh.lesson_num, lt.lessontime, ls.lesson_name, ls.lesson_name_eng
    FROM D_Schedule sh, BE_WeekDay wd, D_Lesson ls, BE_lesson_Time lt
    WHERE sh.weekday_id = wd.id
      AND sh.lesson_id = ls.id
      AND sh.lesson_num = lt.lesson_num
      AND wd.id = ?
      ORDER BY sh.lesson_num""", (week_day,)).fetchall()
    result2 = cur.execute("""SELECT wd.id, wd.weekday_name
                                 FROM  BE_WeekDay wd
                                 WHERE wd.id = ?""", (week_day,)).fetchall()[0][1]
    for elem in result:
        list_less.append(str(elem[0]) + '. ' + elem[1] + ' ' + elem[2])
    con.close()
    return list_less, result2


app = Flask(__name__)


@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == 'GET':
        param = {}

        param['lesson1'] = 'Миссия Колонизация Марса'
        return render_template('base.html', **param)
    elif request.method == 'POST':
        print(request.form['calendar'])
        param = {}
        param['week_day'] = 'Миссия'
        param['lesson1'] = 'Миссия Колонизация Марса'
        return render_template('base.html', **param)


@app.route('/page2', methods=['POST', 'GET'])
def index2():
    global global_data
    global months_day
    data = request.get_json(silent=True)

    param = {}
    param['position_checkbox2'] = 'checked'
    param['date_tab'] = str(global_data.day) + ' ' + months_day[global_data.month - 1]
    param['date_cal'] = global_data.strftime('%Y-%m-%d')
    now = global_data
    list_less = tomorrow(now)[0]
    param['week_day'] = tomorrow(now)[1]
    for i in range(len(list_less)):
        param['lesson' + str(i + 1)] = list_less[i]

    if request.method == 'GET':
        return render_template('page2.html', **param)

    elif request.method == 'POST':
        year = int(request.form['calendar'][0] + request.form['calendar'][1] + request.form['calendar'][2] + request.form['calendar'][3])
        month = int(request.form['calendar'][5] + request.form['calendar'][6])
        day = int(request.form['calendar'][8] + request.form['calendar'][9])
        global_data = datetime.date(year, month, day)
        #global_data = global_data + datetime.timedelta(days=1)
        now = global_data
        list_less = tomorrow(now)[0]
        param['week_day'] = tomorrow(now)[1]
        param['date_tab'] = str(global_data.day) + ' ' + months_day[global_data.month - 1]
        param['date_cal'] = global_data.strftime('%Y-%m-%d')
        for i in range(len(list_less)):
            param['lesson' + str(i + 1)] = list_less[i]
        return render_template('page2.html', **param)



if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')