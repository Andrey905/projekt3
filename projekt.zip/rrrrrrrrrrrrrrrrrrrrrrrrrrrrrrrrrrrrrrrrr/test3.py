from flask import Flask, render_template, Response, request, redirect, url_for
app = Flask(__name__)

@app.route("/")
def index():
    return render_template('base.html')

@app.route("/forward/", methods=['POST'])
def move_forward():
    #Moving forward code
    forward_message = "Moving Forward..."
    print('Moving Forward11111111111')
    return render_template('base.html')

@app.route("/forward2/", methods=['POST'])
def move_forward2():
    #Moving forward code
    forward_message = "Moving Forward..."
    print('Moving Forward2222222222')
    return render_template('base.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')